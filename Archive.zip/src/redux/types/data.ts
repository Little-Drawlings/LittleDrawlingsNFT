export interface SavePopupProps {
	title?: string;
	desc?: string;
	drawlName?: string;
	drawl: string;
	time: number;
	format: string;

}