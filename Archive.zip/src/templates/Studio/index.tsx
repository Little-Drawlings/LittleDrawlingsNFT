import Studio from './Studio';

export default Studio;