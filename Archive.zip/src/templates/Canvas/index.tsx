import Canvas from './Canvas';

export default Canvas;