import DefaultInput from './DefaultInput';

export default DefaultInput;